
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const WelcomeSection = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0 md:pr-10">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-6 text-church-dark">
              Welcome to <span className="text-church-primary">A New Thing Parish</span>
            </h2>
            <div className="w-20 h-1 bg-church-secondary mb-6"></div>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              At RCCG A New Thing Parish, we believe in fostering a community where 
              faith, love, and service converge. Our mission is to bring people to 
              the saving knowledge of Jesus Christ and help them grow spiritually.
            </p>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Whether you're a long-time believer or just beginning to explore faith, 
              you'll find a warm and welcoming community here. We invite you to join us 
              for worship and discover how God is doing a new thing in your life.
            </p>
            <Button 
              asChild
              className="bg-church-primary hover:bg-church-secondary text-white font-medium"
            >
              <Link to="/about">About Our Church</Link>
            </Button>
          </div>
          <div className="md:w-1/2">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-full h-full border-2 border-church-primary"></div>
              <img 
                src="https://images.unsplash.com/photo-1473177104440-ffee2f376098?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80" 
                alt="Church interior" 
                className="relative z-10 w-full h-auto"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WelcomeSection;
